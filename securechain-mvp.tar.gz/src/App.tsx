import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { graphData, type Node } from './data';
import './App.css';

function App() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    // Clear previous
    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    // Color mapping
    const colorMap = {
      organization: '#3b82f6',
      product: '#10b981',
      software: '#f59e0b',
      vulnerability: '#ef4444'
    };

    // Create simulation
    const simulation = d3.forceSimulation(graphData.nodes as any)
      .force('link', d3.forceLink(graphData.edges)
        .id((d: any) => d.id)
        .distance(100))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(30));

    // Create links
    const link = svg.append('g')
      .selectAll('line')
      .data(graphData.edges)
      .join('line')
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.6)
      .attr('stroke-width', 2);

    // Create nodes
    const node = svg.append('g')
      .selectAll('circle')
      .data(graphData.nodes)
      .join('circle')
      .attr('r', (d: Node) => 5 + (d.risk_score / 10))
      .attr('fill', (d: Node) => colorMap[d.type])
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .style('cursor', 'pointer')
      .call(d3.drag<any, Node>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended) as any);

    // Create labels
    const labels = svg.append('g')
      .selectAll('text')
      .data(graphData.nodes)
      .join('text')
      .text((d: Node) => d.name)
      .attr('font-size', 10)
      .attr('dx', 12)
      .attr('dy', 4)
      .style('pointer-events', 'none');

    // Tooltips
    const tooltip = d3.select('body').append('div')
      .style('position', 'absolute')
      .style('padding', '8px')
      .style('background', 'rgba(0, 0, 0, 0.8)')
      .style('color', '#fff')
      .style('border-radius', '4px')
      .style('pointer-events', 'none')
      .style('opacity', 0)
      .style('font-size', '12px');

    node
      .on('mouseenter', (event: MouseEvent, d: Node) => {
        tooltip.transition().duration(200).style('opacity', 1);
        tooltip.html(`
          <strong>${d.name}</strong><br/>
          Type: ${d.type}<br/>
          Risk Score: ${d.risk_score}
        `)
          .style('left', (event.pageX + 10) + 'px')
          .style('top', (event.pageY - 10) + 'px');
      })
      .on('mouseleave', () => {
        tooltip.transition().duration(200).style('opacity', 0);
      });

    // Update positions
    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('cx', (d: any) => d.x)
        .attr('cy', (d: any) => d.y);

      labels
        .attr('x', (d: any) => d.x)
        .attr('y', (d: any) => d.y);
    });

    // Drag functions
    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    return () => {
      tooltip.remove();
    };
  }, []);

  return (
    <div className="app">
      <div className="header">
        <h1>SecureChain MVP</h1>
        <div className="legend">
          <span className="legend-item"><span className="dot org"></span> Organization</span>
          <span className="legend-item"><span className="dot prod"></span> Product</span>
          <span className="legend-item"><span className="dot soft"></span> Software</span>
          <span className="legend-item"><span className="dot vuln"></span> Vulnerability</span>
        </div>
      </div>
      <svg ref={svgRef}></svg>
    </div>
  );
}

export default App;
